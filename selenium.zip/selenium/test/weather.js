const { Key } = require("selenium-webdriver");
const { By } = require("selenium-webdriver");
const {Builder} = require ("selenium-webdriver");


async function example(){


let driver = await new Builder().forBrowser("chrome").build();


await driver.get("https://www.accuweather.com/")
    
await driver.findElement(By.name("query")).sendKeys("Delhi, Delhi, IN",Key.ENTER);

time.sleep(20);

weather_element = driver.find_element(By.CLASS_NAME, "temp");
current_weather = weather_element.text

print("Current weather in Delhi, Delhi, IN:", current_weather);

await driver.findElement(By.xpath("//span[contains(text(), 'Monthly')]"))

let maxTemperature = -Infinity;
        let warmestDay = '';

        
        for (const element of temperatureElements) {
            const temperatureText = await element.getText();
            const temperature = parseFloat(temperatureText);

            if (!isNaN(temperature) && temperature > maxTemperature) {
                maxTemperature = temperature;
                warmestDay = await driver.findElement(By.xpath("(//div[@class='high  '])[3]")).getText();
            }
        }

        console.log(`Warmest day: ${warmestDay}`);
        console.log(`Maximum temperature: ${maxTemperature}°C`);

        await driver.quit();
  
    }












